import { Ionicons } from "@expo/vector-icons";
import { useRef, useState } from "react";
import { Platform, Pressable, StyleSheet, Text, View } from "react-native";

import { GlassCard, GlowButton, IconBubble, palette, StatusDot } from "@/components/neuro-ui";

export function VoiceAssistantPanel({ language, latestAnswer, onTranscript }: { language: string; latestAnswer: string; onTranscript: (text: string) => void }) {
  const [listening, setListening] = useState(false);
  const [status, setStatus] = useState("Microphone is off");
  const recognitionRef = useRef<any>(null);

  function browserLanguage() {
    if (language === "Urdu") return "ur-PK";
    if (language === "Roman Urdu") return "en-PK";
    if (language === "Sindhi") return "sd-PK";
    return "en-US";
  }

  function toggleListening() {
    if (listening) {
      recognitionRef.current?.stop?.();
      setListening(false);
      setStatus("Listening stopped");
      return;
    }
    if (Platform.OS !== "web") {
      setStatus("Microphone permission and speech capture depend on the native build. Use the device keyboard microphone or connect a native speech adapter.");
      return;
    }
    const browserWindow = globalThis as any;
    const Recognition = browserWindow.webkitSpeechRecognition || browserWindow.SpeechRecognition;
    if (!Recognition) {
      setStatus("This browser does not support speech recognition. You can still type your question.");
      return;
    }
    const recognition = new Recognition();
    recognition.lang = browserLanguage();
    recognition.interimResults = false;
    recognition.continuous = false;
    recognition.onstart = () => { setListening(true); setStatus("Listening… speak your question"); };
    recognition.onresult = (event: any) => {
      const text = event?.results?.[0]?.[0]?.transcript;
      if (text) { onTranscript(text); setStatus("Transcription ready — review it before sending"); }
    };
    recognition.onerror = (event: any) => { setListening(false); setStatus(`Microphone error: ${event?.error || "permission or browser issue"}`); };
    recognition.onend = () => setListening(false);
    recognitionRef.current = recognition;
    try { recognition.start(); } catch { setStatus("Microphone could not start. Check permission and try again."); }
  }

  function speakAnswer() {
    if (!latestAnswer) { setStatus("Ask Neuro a question first, then playback will be available."); return; }
    if (Platform.OS !== "web" || !(globalThis as any).speechSynthesis) {
      setStatus("Text-to-speech playback is available in supported browsers; native playback needs the platform audio adapter.");
      return;
    }
    const speech = new SpeechSynthesisUtterance(latestAnswer);
    speech.lang = browserLanguage();
    (globalThis as any).speechSynthesis.cancel();
    (globalThis as any).speechSynthesis.speak(speech);
    setStatus("Playing Neuro’s answer");
  }

  return <GlassCard accent="violet" style={voiceStyles.card}><View style={voiceStyles.header}><View style={voiceStyles.titleRow}><IconBubble icon="mic-outline" color={palette.magenta} size={36} /><View><Text style={voiceStyles.title}>Talk to Neuro</Text><StatusDot label={status} tone={listening ? "warning" : "good"} /></View></View><Text style={voiceStyles.language}>{language}</Text></View><Text style={voiceStyles.description}>Use your voice when supported, review the transcription, then send it through the normal chat composer. No recording is secretly stored.</Text><View style={voiceStyles.actions}><GlowButton onPress={toggleListening} variant={listening ? "primary" : "outline"} icon={listening ? "stop" : "mic-outline"}>{listening ? "Stop listening" : "Start listening"}</GlowButton><Pressable onPress={speakAnswer} style={voiceStyles.playButton}><Ionicons name="volume-high-outline" size={17} color={palette.cyan} /><Text style={voiceStyles.playText}>Play last answer</Text></Pressable></View></GlassCard>;
}

const voiceStyles = StyleSheet.create({
  card: { marginTop: 16 },
  header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  titleRow: { flexDirection: "row", alignItems: "center", gap: 10 },
  title: { color: palette.text, fontSize: 16, fontWeight: "800" },
  language: { color: palette.cyan, fontSize: 11, fontWeight: "800" },
  description: { color: palette.muted, fontSize: 12, lineHeight: 18, marginTop: 11 },
  actions: { flexDirection: "row", alignItems: "center", flexWrap: "wrap", gap: 10, marginTop: 14 },
  playButton: { minHeight: 44, borderWidth: 1, borderColor: palette.border, borderRadius: 999, paddingHorizontal: 15, flexDirection: "row", alignItems: "center", gap: 7 },
  playText: { color: palette.text, fontSize: 13, fontWeight: "700" },
});
