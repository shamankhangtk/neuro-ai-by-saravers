import { Ionicons } from "@expo/vector-icons";
import { ReactNode } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";

export const palette = {
  bg: "#050B22",
  bgSoft: "#081337",
  panel: "#0B1640",
  panelAlt: "#111A49",
  border: "#273B88",
  cyan: "#2BE0FF",
  blue: "#4A7CFF",
  violet: "#985BFF",
  magenta: "#E65BFF",
  text: "#F6F8FF",
  muted: "#94A6D3",
  subtle: "#6073A6",
  good: "#62E5B4",
  warning: "#FFC56C",
  danger: "#FF7B9C",
};

export function Eyebrow({ children, icon }: { children: ReactNode; icon?: keyof typeof Ionicons.glyphMap }) {
  return (
    <View style={styles.eyebrow}>
      {icon ? <Ionicons name={icon} size={13} color={palette.cyan} /> : null}
      <Text style={styles.eyebrowText}>{children}</Text>
    </View>
  );
}

export function GlassCard({ children, style, accent = "blue" }: { children: ReactNode; style?: any; accent?: "blue" | "violet" | "cyan" }) {
  const accentColor = accent === "violet" ? palette.violet : accent === "cyan" ? palette.cyan : palette.blue;
  return <View style={[styles.card, { borderColor: `${accentColor}55` }, style]}>{children}</View>;
}

export function IconBubble({ icon, color = palette.cyan, size = 42 }: { icon: keyof typeof Ionicons.glyphMap; color?: string; size?: number }) {
  return (
    <View style={{ width: size, height: size, borderRadius: size / 2, alignItems: "center", justifyContent: "center", backgroundColor: `${color}1B`, borderWidth: 1, borderColor: `${color}70` }}>
      <Ionicons name={icon} size={size * 0.48} color={color} />
    </View>
  );
}

export function GlowButton({ children, onPress, icon, variant = "primary", disabled = false, style }: { children: ReactNode; onPress?: () => void; icon?: keyof typeof Ionicons.glyphMap; variant?: "primary" | "outline" | "ghost"; disabled?: boolean; style?: any }) {
  const primary = variant === "primary";
  return (
    <Pressable disabled={disabled} onPress={onPress} style={({ pressed }) => [styles.button, primary ? styles.buttonPrimary : variant === "outline" ? styles.buttonOutline : styles.buttonGhost, pressed && { opacity: 0.78, transform: [{ scale: 0.98 }] }, disabled && { opacity: 0.45 }, style]}>
      <Text style={[styles.buttonText, !primary && { color: palette.text }]}>{children}</Text>
      {icon ? <Ionicons name={icon} size={16} color={primary ? "#07112E" : palette.cyan} /> : null}
    </Pressable>
  );
}

export function StatusDot({ label, tone = "good" }: { label: string; tone?: "good" | "warning" | "danger" }) {
  const color = tone === "good" ? palette.good : tone === "warning" ? palette.warning : palette.danger;
  return (
    <View style={styles.statusRow}>
      <View style={[styles.statusDot, { backgroundColor: color, shadowColor: color }]} />
      <Text style={styles.statusText}>{label}</Text>
    </View>
  );
}

export function SectionTitle({ eyebrow, title, description, action }: { eyebrow?: string; title: string; description?: string; action?: ReactNode }) {
  return (
    <View style={styles.sectionHeading}>
      <View style={{ flex: 1 }}>
        {eyebrow ? <Text style={styles.sectionEyebrow}>{eyebrow}</Text> : null}
        <Text style={styles.sectionTitle}>{title}</Text>
        {description ? <Text style={styles.sectionDescription}>{description}</Text> : null}
      </View>
      {action}
    </View>
  );
}

export const styles = StyleSheet.create({
  card: { backgroundColor: "#0B1539E8", borderWidth: 1, borderRadius: 20, padding: 18, shadowColor: "#000", shadowOpacity: 0.28, shadowRadius: 18, shadowOffset: { width: 0, height: 10 }, elevation: 4 },
  eyebrow: { flexDirection: "row", alignItems: "center", gap: 7, alignSelf: "flex-start", borderWidth: 1, borderColor: `${palette.violet}88`, backgroundColor: `${palette.violet}12`, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 7 },
  eyebrowText: { color: "#B4B8FF", fontSize: 11, letterSpacing: 1.4, fontWeight: "700" },
  button: { minHeight: 44, borderRadius: 999, paddingHorizontal: 17, flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8 },
  buttonPrimary: { backgroundColor: palette.cyan, shadowColor: palette.cyan, shadowOpacity: 0.34, shadowRadius: 12, shadowOffset: { width: 0, height: 5 }, elevation: 3 },
  buttonOutline: { borderWidth: 1, borderColor: `${palette.cyan}88`, backgroundColor: `${palette.cyan}0A` },
  buttonGhost: { backgroundColor: "transparent" },
  buttonText: { color: "#06112B", fontWeight: "800", fontSize: 14 },
  statusRow: { flexDirection: "row", alignItems: "center", gap: 8 },
  statusDot: { width: 8, height: 8, borderRadius: 4, shadowOpacity: 0.9, shadowRadius: 8 },
  statusText: { color: palette.muted, fontSize: 12 },
  sectionHeading: { flexDirection: "row", alignItems: "flex-end", gap: 16, marginBottom: 16 },
  sectionEyebrow: { color: palette.cyan, fontSize: 11, letterSpacing: 1.8, fontWeight: "800", marginBottom: 7 },
  sectionTitle: { color: palette.text, fontSize: 26, fontWeight: "800", letterSpacing: -0.5 },
  sectionDescription: { color: palette.muted, fontSize: 14, lineHeight: 21, marginTop: 7, maxWidth: 620 },
});
