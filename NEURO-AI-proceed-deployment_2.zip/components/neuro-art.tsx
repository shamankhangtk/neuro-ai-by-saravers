import Svg, {
  Circle,
  Defs,
  Ellipse,
  G,
  LinearGradient,
  Path,
  Stop,
} from "react-native-svg";
import { View } from "react-native";

const cyan = "#2BE0FF";
const violet = "#9A55FF";
const magenta = "#F05CFF";

export function NeuroMark({ size = 42 }: { size?: number }) {
  return (
    <View style={{ width: size, height: size }}>
      <Svg width={size} height={size} viewBox="0 0 48 48">
        <Defs>
          <LinearGradient id="markGradient" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor={cyan} />
            <Stop offset="0.52" stopColor="#657BFF" />
            <Stop offset="1" stopColor={violet} />
          </LinearGradient>
        </Defs>
        <Path d="M24 42c-3-3-8-3-11-8-2-3-1-6-4-8 3-1 4-4 3-7-1-4 1-8 5-9 2-7 13-7 15 0 4 1 6 5 5 9-1 3 0 6 3 7-3 2-2 5-4 8-3 5-8 5-11 8Z" fill="#101A44" stroke="url(#markGradient)" strokeWidth="2.2" />
        <Path d="M24 12v25M18 14c2 3 2 5 2 7M30 14c-2 3-2 5-2 7M15 23c3-1 5 0 7 2M33 23c-3-1-5 0-7 2M18 31c2-2 4-2 6 0M30 31c-2-2-4-2-6 0" fill="none" stroke="url(#markGradient)" strokeWidth="1.7" strokeLinecap="round" />
        <Circle cx="24" cy="10" r="2" fill={cyan} />
        <Circle cx="12" cy="22" r="1.8" fill={magenta} />
        <Circle cx="36" cy="22" r="1.8" fill={violet} />
      </Svg>
    </View>
  );
}

export function NeuralHeroArt({ compact = false }: { compact?: boolean }) {
  const size = compact ? 260 : 430;
  return (
    <View style={{ width: size, height: size, alignItems: "center", justifyContent: "center" }}>
      <View style={{ position: "absolute", width: size * 0.78, height: size * 0.78, borderRadius: size, backgroundColor: "#2734FF", opacity: 0.1 }} />
      <Svg width={size} height={size} viewBox="0 0 430 430">
        <Defs>
          <LinearGradient id="coil" x1="0" y1="0" x2="1" y2="1">
            <Stop offset="0" stopColor={cyan} />
            <Stop offset="0.34" stopColor="#4B78FF" />
            <Stop offset="0.68" stopColor={magenta} />
            <Stop offset="1" stopColor={violet} />
          </LinearGradient>
          <LinearGradient id="platform" x1="0" y1="0" x2="1" y2="0">
            <Stop offset="0" stopColor="#2BE0FF" stopOpacity="0" />
            <Stop offset="0.5" stopColor="#2BE0FF" stopOpacity="0.95" />
            <Stop offset="1" stopColor="#9A55FF" stopOpacity="0" />
          </LinearGradient>
        </Defs>
        <G opacity="0.38" fill="none" stroke="#5D78FF">
          <Ellipse cx="215" cy="215" rx="176" ry="88" strokeWidth="1" />
          <Ellipse cx="215" cy="215" rx="146" ry="158" strokeWidth="1" transform="rotate(24 215 215)" />
          <Ellipse cx="215" cy="215" rx="188" ry="118" strokeWidth="0.7" transform="rotate(-32 215 215)" />
        </G>
        <G fill="none" stroke="url(#coil)" strokeLinecap="round">
          <Path d="M92 164c42-47 114-50 164-18 33 21 84 18 94-13 8-26-25-52-61-46-43 7-75 47-61 70 16 27 94 24 128 65 31 37-3 74-46 73-53-2-73-51-113-64-39-13-88 20-105-13-11-22 5-40 28-47 44-14 91 10 96 40 6 38-54 54-89 35-24-13-43-40-35-64Z" strokeWidth="10" />
          <Path d="M113 204c32-30 84-36 124-17 38 19 92 51 111 22 18-27-17-57-47-50-31 7-43 34-28 53 19 25 91 32 91 69 0 26-37 36-69 17-34-20-52-60-97-61-45-1-69 33-96 12-22-17-12-38 11-45Z" strokeWidth="7" opacity="0.88" />
          <Path d="M146 254c28-16 64-7 82 17 19 25 69 31 81 8 11-20-17-41-40-34-26 8-24 34-8 50 15 15 54 18 56 44" strokeWidth="5" opacity="0.84" />
        </G>
        <G fill={cyan}>
          <Circle cx="92" cy="164" r="4" />
          <Circle cx="289" cy="87" r="4" fill={magenta} />
          <Circle cx="350" cy="198" r="4" fill={violet} />
          <Circle cx="241" cy="319" r="4" />
        </G>
        <Path d="M72 358c86-18 205-19 286 0" stroke="url(#platform)" strokeWidth="5" strokeLinecap="round" opacity="0.9" />
        <Ellipse cx="215" cy="365" rx="128" ry="17" fill="none" stroke="#3B60FF" strokeWidth="1" opacity="0.7" />
        <Ellipse cx="215" cy="365" rx="88" ry="9" fill="#2BE0FF" opacity="0.14" />
      </Svg>
    </View>
  );
}
