import { Ionicons } from "@expo/vector-icons";
import { useEffect, useState } from "react";
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";

import { GlassCard, GlowButton, IconBubble, palette, SectionTitle, StatusDot } from "@/components/neuro-ui";
import { getAdminLoginConfig, loginAdmin, logoutAdmin, NeuroApiError, requestAdminEdit } from "@/lib/neuro-api";

const defaultUsername = "saraverse.edu.gov.pk";

export function AdminLoginScreen() {
  const [username, setUsername] = useState(defaultUsername);
  const [password, setPassword] = useState("");
  const [token, setToken] = useState("");
  const [prompt, setPrompt] = useState("");
  const [proposal, setProposal] = useState("");
  const [note, setNote] = useState("");
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    getAdminLoginConfig().then((config) => {
      if (config.username) setUsername(config.username);
    }).catch(() => undefined);
  }, []);

  async function login() {
    if (!username.trim() || !password) return;
    setLoading(true); setStatus("");
    try {
      const result = await loginAdmin(username, password);
      setToken(result.token);
      setPassword("");
      setStatus("Admin session active for 8 hours on this device.");
    } catch (error) {
      setStatus(error instanceof NeuroApiError ? error.message : "Login failed. Please try again.");
    } finally { setLoading(false); }
  }

  async function createProposal() {
    if (!token || !prompt.trim() || loading) return;
    setLoading(true); setStatus(""); setProposal(""); setNote("");
    try {
      const result = await requestAdminEdit(token, prompt);
      setProposal(result.proposal); setNote(result.note);
    } catch (error) {
      setStatus(error instanceof NeuroApiError ? error.message : "The prompt editor is unavailable right now.");
    } finally { setLoading(false); }
  }

  async function logout() {
    if (token) await logoutAdmin(token).catch(() => undefined);
    setToken(""); setProposal(""); setPrompt(""); setStatus("Logged out securely.");
  }

  return <ScrollView contentContainerStyle={styles.content}><SectionTitle eyebrow="ADMIN ACCESS" title="Manage Neuro AI safely." description="Login is server-validated. The password is never bundled into the Android APK, Windows wrapper or browser code." />{!token ? <GlassCard accent="cyan" style={styles.loginCard}><View style={styles.loginHeading}><IconBubble icon="lock-closed-outline" color={palette.cyan} size={48} /><View><Text style={styles.panelTitle}>Neuro AI Login</Text><StatusDot label="Protected server session" /></View></View><Text style={styles.label}>Username</Text><TextInput value={username} onChangeText={setUsername} autoCapitalize="none" autoCorrect={false} placeholder={defaultUsername} placeholderTextColor={palette.subtle} style={styles.input} /><Text style={styles.label}>Password</Text><TextInput value={password} onChangeText={setPassword} secureTextEntry placeholder="Enter admin password" placeholderTextColor={palette.subtle} style={styles.input} /><GlowButton onPress={login} icon="log-in-outline" disabled={!username.trim() || !password || loading}>{loading ? "Signing in…" : "Login"}</GlowButton><Text style={styles.securityNote}>The default username is prefilled. The password is configured as a protected server secret and is intentionally not prefilled in the app.</Text>{status ? <View style={styles.statusBox}><Ionicons name="information-circle-outline" size={17} color={palette.cyan} /><Text style={styles.statusText}>{status}</Text></View> : null}</GlassCard> : <><GlassCard accent="violet"><View style={styles.loginHeading}><IconBubble icon="shield-checkmark-outline" color={palette.good} size={48} /><View style={{ flex: 1 }}><Text style={styles.panelTitle}>Authenticated admin</Text><StatusDot label="Session verified" /></View><Pressable onPress={logout} style={styles.logout}><Ionicons name="log-out-outline" size={16} color={palette.danger} /><Text style={styles.logoutText}>Logout</Text></Pressable></View><Text style={styles.bodyText}>Describe a supported app change in plain language. Neuro will prepare a reviewable proposal with affected screens, implementation steps and risks.</Text></GlassCard><GlassCard accent="cyan" style={{ marginTop: 16 }}><Text style={styles.panelTitle}>Prompt Editor</Text><TextInput value={prompt} onChangeText={setPrompt} multiline placeholder="Example: Change the homepage supporting text to focus on science students…" placeholderTextColor={palette.subtle} style={[styles.input, styles.textArea]} /><GlowButton onPress={createProposal} icon="sparkles" disabled={!prompt.trim() || loading}>{loading ? "Preparing proposal…" : "Create change proposal"}</GlowButton>{status ? <View style={styles.statusBox}><Ionicons name="information-circle-outline" size={17} color={palette.cyan} /><Text style={styles.statusText}>{status}</Text></View> : null}</GlassCard>{proposal ? <GlassCard accent="violet" style={{ marginTop: 16 }}><Text style={styles.panelTitle}>Reviewable proposal</Text><Text style={styles.proposal}>{proposal}</Text><Text style={styles.securityNote}>{note}</Text></GlassCard> : null}</>}</ScrollView>;
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 22, paddingVertical: 28, paddingBottom: 50, maxWidth: 900, width: "100%", alignSelf: "center" },
  loginCard: { maxWidth: 620, width: "100%", alignSelf: "center" },
  loginHeading: { flexDirection: "row", alignItems: "center", gap: 12, marginBottom: 16 },
  panelTitle: { color: palette.text, fontSize: 18, fontWeight: "800" },
  label: { color: palette.muted, fontSize: 12, fontWeight: "800", marginTop: 12, marginBottom: 5 },
  input: { borderWidth: 1, borderColor: palette.border, backgroundColor: "#071131", color: palette.text, borderRadius: 12, minHeight: 45, paddingHorizontal: 13, fontSize: 14, marginBottom: 12 },
  textArea: { minHeight: 145, textAlignVertical: "top", paddingTop: 12 },
  securityNote: { color: palette.subtle, fontSize: 11, lineHeight: 17, marginTop: 12 },
  statusBox: { flexDirection: "row", alignItems: "flex-start", gap: 8, padding: 10, borderRadius: 11, backgroundColor: "#10224B", borderWidth: 1, borderColor: palette.border, marginTop: 12 },
  statusText: { color: palette.muted, fontSize: 12, lineHeight: 18, flex: 1 },
  bodyText: { color: palette.muted, fontSize: 14, lineHeight: 22, marginTop: 10 },
  logout: { flexDirection: "row", alignItems: "center", gap: 5, borderWidth: 1, borderColor: "#71364F", paddingHorizontal: 10, paddingVertical: 8, borderRadius: 999 },
  logoutText: { color: palette.danger, fontSize: 12, fontWeight: "700" },
  proposal: { color: "#DCE4FF", fontSize: 14, lineHeight: 23, marginTop: 14 },
});
