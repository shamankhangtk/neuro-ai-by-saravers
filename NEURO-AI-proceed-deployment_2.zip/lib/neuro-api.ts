import type { ChatMessage } from "./neuro-storage";

type ApiErrorBody = { error?: { message?: string } | string; message?: string };

export class NeuroApiError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = "NeuroApiError";
    this.status = status;
  }
}

function apiBase() {
  const envBase = process.env.EXPO_PUBLIC_API_BASE_URL;
  return envBase || "";
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  let response: Response;
  try {
    response = await fetch(`${apiBase()}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
  } catch {
    throw new NeuroApiError("Network connection failed. Please check your connection and try again.");
  }

  const text = await response.text();
  let parsed: (T & ApiErrorBody) | null = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  if (!response.ok) {
    const errorValue = parsed?.error;
    const message = typeof errorValue === "string" ? errorValue : errorValue?.message || parsed?.message || "The AI service is unavailable right now.";
    throw new NeuroApiError(message, response.status);
  }
  if (!parsed) throw new NeuroApiError("The AI service returned an empty response.");
  return parsed as T;
}

async function postAuthorized<T>(path: string, token: string, body: unknown) {
  let response: Response;
  try {
    response = await fetch(`${apiBase()}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
  } catch {
    throw new NeuroApiError("Network connection failed. Please check your connection and try again.");
  }
  const text = await response.text();
  let parsed: (T & ApiErrorBody) | null = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  if (!response.ok) {
    const errorValue = parsed?.error;
    const message = typeof errorValue === "string" ? errorValue : errorValue?.message || parsed?.message || "The admin service is unavailable right now.";
    throw new NeuroApiError(message, response.status);
  }
  if (!parsed) throw new NeuroApiError("The admin service returned an empty response.");
  return parsed as T;
}

export async function getAdminLoginConfig() {
  const response = await fetch(`${apiBase()}/api/neuro/auth/config`);
  if (!response.ok) throw new NeuroApiError("Admin login configuration is unavailable.", response.status);
  return (await response.json()) as { username: string };
}

export async function loginAdmin(username: string, password: string) {
  return postJson<{ token: string; expiresIn: number }>("/api/neuro/auth/login", { username, password });
}

export async function logoutAdmin(token: string) {
  return postAuthorized<{ ok: boolean }>("/api/neuro/auth/logout", token, {});
}

export async function requestAdminEdit(token: string, prompt: string) {
  return postAuthorized<{ proposal: string; note: string }>("/api/neuro/admin/edit", token, { prompt });
}

export async function askNeuro(messages: ChatMessage[], options?: { language?: string; answerStyle?: string; searchWeb?: boolean }) {
  return postJson<{ content: string; model?: string }>("/api/neuro/chat", {
    messages: messages.map(({ role, content }) => ({ role, content })),
    language: options?.language,
    answerStyle: options?.answerStyle,
    searchWeb: options?.searchWeb === true,
  });
}

export async function generateNeuroImage(input: { prompt: string; negativePrompt?: string; style: string; aspectRatio: string }) {
  return postJson<{ url?: string; b64Json?: string; mimeType?: string }>("/api/neuro/image", input);
}
