import AsyncStorage from "@react-native-async-storage/async-storage";

export type NeuroPreferences = {
  language: string;
  answerStyle: "Simple" | "Detailed";
  voicePlayback: boolean;
  imageStyle: string;
  darkMode: boolean;
};

export type ChatMessage = {
  id: string;
  role: "user" | "assistant" | "system";
  content: string;
  createdAt: number;
};

const keys = {
  preferences: "neuroai.preferences",
  chats: "neuroai.chats",
  reading: "neuroai.reading",
};

export const defaultPreferences: NeuroPreferences = {
  language: "Follow my language",
  answerStyle: "Simple",
  voicePlayback: false,
  imageStyle: "Futuristic",
  darkMode: true,
};

export async function loadPreferences() {
  try {
    const raw = await AsyncStorage.getItem(keys.preferences);
    return raw ? { ...defaultPreferences, ...JSON.parse(raw) } : defaultPreferences;
  } catch {
    return defaultPreferences;
  }
}

export async function savePreferences(value: NeuroPreferences) {
  await AsyncStorage.setItem(keys.preferences, JSON.stringify(value));
}

export async function loadChats(): Promise<ChatMessage[]> {
  try {
    const raw = await AsyncStorage.getItem(keys.chats);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export async function saveChats(value: ChatMessage[]) {
  await AsyncStorage.setItem(keys.chats, JSON.stringify(value.slice(-80)));
}

export async function loadReadingList(): Promise<Record<string, "Want to Read" | "Reading" | "Completed">> {
  try {
    const raw = await AsyncStorage.getItem(keys.reading);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export async function saveReadingList(value: Record<string, "Want to Read" | "Reading" | "Completed">) {
  await AsyncStorage.setItem(keys.reading, JSON.stringify(value));
}

export async function clearNeuroHistory() {
  await AsyncStorage.removeItem(keys.chats);
  await AsyncStorage.removeItem(keys.reading);
}
