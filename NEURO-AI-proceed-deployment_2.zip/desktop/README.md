# NEURO AI Windows desktop wrapper

This wrapper opens the same responsive Expo Web interface used by the app preview, so the desktop presentation stays aligned with the Android UI. It deliberately keeps Node integration disabled and opens external links in the system browser.

## Local development

From this directory:

```bash
npm install
NEURO_AI_URL=http://localhost:8081 npm run dev
```

## Windows EXE build

On a Windows machine with Node.js installed:

```powershell
npm install
$env:NEURO_AI_URL = "https://your-published-neuro-ai-origin"
npm run dist:win
```

The `portable` target creates a portable `.exe`; the `nsis` target creates an installable Windows setup. Use a published HTTPS origin or a locally running Expo Web/API pair. The actual `.exe` must be produced on a Windows packaging environment; this Linux sandbox does not contain Wine or a Windows signing toolchain, so no unbuilt `.exe` is claimed from this source handoff.
