import { Ionicons } from "@expo/vector-icons";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useEffect, useMemo, useState, type ReactNode } from "react";
import {
  ActivityIndicator,
  Alert,
  Image,
  Linking,
  Platform,
  Pressable,
  ScrollView,
  Share,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  useWindowDimensions,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";

import { NeuralHeroArt, NeuroMark } from "@/components/neuro-art";
import { AdminLoginScreen } from "@/components/admin-login";
import { Eyebrow, GlassCard, GlowButton, IconBubble, palette, SectionTitle, StatusDot } from "@/components/neuro-ui";
import { VoiceAssistantPanel } from "@/components/voice-assistant";
import { askNeuro, generateNeuroImage, NeuroApiError } from "@/lib/neuro-api";
import {
  ChatMessage,
  defaultPreferences,
  loadChats,
  loadPreferences,
  loadReadingList,
  NeuroPreferences,
  saveChats,
  savePreferences,
  saveReadingList,
} from "@/lib/neuro-storage";

const navItems = [
  { key: "home", label: "Home", icon: "home-outline" },
  { key: "chat", label: "Neuro Chat", icon: "chatbubbles-outline" },
  { key: "study", label: "Study Tools", icon: "book-outline" },
  { key: "image", label: "AI Image Studio", icon: "image-outline" },
  { key: "library", label: "Library", icon: "library-outline" },
  { key: "create", label: "CreateLab", icon: "sparkles-outline" },
  { key: "coding", label: "Coding Help", icon: "code-slash-outline" },
  { key: "about", label: "About", icon: "information-circle-outline" },
  { key: "settings", label: "Settings", icon: "settings-outline" },
  { key: "login", label: "Login", icon: "lock-closed-outline" },
] as const;

type SectionKey = (typeof navItems)[number]["key"];
type IconName = keyof typeof Ionicons.glyphMap;

type Book = {
  id: string;
  title: string;
  author: string;
  subject: string;
  description: string;
  cover: string;
};

const books: Book[] = [
  { id: "sapiens", title: "Sapiens", author: "Yuval Noah Harari", subject: "History", description: "A broad story of how humans shaped the world and our ideas.", cover: "#4932A8" },
  { id: "atomic", title: "Atomic Habits", author: "James Clear", subject: "Productivity", description: "Practical ideas for building better habits through small changes.", cover: "#0C7894" },
  { id: "cosmos", title: "Cosmos", author: "Carl Sagan", subject: "Science", description: "A celebrated journey through science, space and human curiosity.", cover: "#7138AF" },
  { id: "pride", title: "Pride and Prejudice", author: "Jane Austen", subject: "Literature", description: "A classic novel about manners, family, first impressions and love.", cover: "#93446C" },
];

function formatTime(value: number) {
  return new Date(value).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

async function copyText(text: string) {
  if (Platform.OS === "web" && typeof navigator !== "undefined" && navigator.clipboard) {
    await navigator.clipboard.writeText(text);
  }
}

async function shareText(title: string, text: string) {
  if (Platform.OS !== "web") await Share.share({ title, message: text });
  else await copyText(text);
}

function confirmAction(message: string, onConfirm: () => void) {
  if (Platform.OS === "web" && typeof window !== "undefined") {
    if (window.confirm(message)) onConfirm();
    return;
  }
  Alert.alert("Please confirm", message, [
    { text: "Cancel", style: "cancel" },
    { text: "Confirm", style: "destructive", onPress: onConfirm },
  ]);
}

function BrandHeader({ active, onNavigate, onGetStarted }: { active: SectionKey; onNavigate: (section: SectionKey) => void; onGetStarted: () => void }) {
  const { width } = useWindowDimensions();
  const compact = width < 980;
  const [open, setOpen] = useState(false);
  return (
    <View style={styles.header}>
      <Pressable style={styles.brand} onPress={() => onNavigate("home")}>
        <NeuroMark size={42} />
        <View>
          <Text style={styles.brandTitle}>NEURO AI</Text>
          <Text style={styles.brandSub}>BY SARAVERS TEAM</Text>
        </View>
      </Pressable>
      {compact ? (
        <Pressable style={styles.menuButton} onPress={() => setOpen((value) => !value)}>
          <Ionicons name={open ? "close" : "menu"} size={24} color={palette.text} />
        </Pressable>
      ) : (
        <View style={styles.desktopNav}>
          {navItems.map((item) => (
            <NavButton key={item.key} item={item} active={active} onPress={() => onNavigate(item.key)} />
          ))}
          <GlowButton onPress={onGetStarted} icon="arrow-forward" style={{ minHeight: 40, paddingHorizontal: 16 }}>Get Started</GlowButton>
        </View>
      )}
      {compact && open ? (
        <View style={styles.mobileMenu}>
          {navItems.map((item) => (
            <NavButton key={item.key} item={item} active={active} onPress={() => { onNavigate(item.key); setOpen(false); }} />
          ))}
          <GlowButton onPress={() => { onGetStarted(); setOpen(false); }} icon="arrow-forward">Get Started</GlowButton>
        </View>
      ) : null}
    </View>
  );
}

function NavButton({ item, active, onPress }: { item: (typeof navItems)[number]; active: SectionKey; onPress: () => void }) {
  const selected = active === item.key;
  return (
    <Pressable onPress={onPress} style={[styles.navButton, selected && styles.navButtonActive]}>
      <Ionicons name={item.icon as IconName} size={16} color={selected ? palette.cyan : palette.muted} />
      <Text style={[styles.navText, selected && { color: palette.text }]}>{item.label}</Text>
    </Pressable>
  );
}

function QuickAction({ icon, title, description, color, onPress }: { icon: IconName; title: string; description: string; color: string; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} style={({ pressed }) => [styles.quickAction, pressed && { opacity: 0.75 }]}>
      <IconBubble icon={icon} color={color} size={42} />
      <View style={{ flex: 1 }}><Text style={styles.quickTitle}>{title}</Text><Text style={styles.quickDescription}>{description}</Text></View>
    </Pressable>
  );
}

function HomeScreen({ navigate }: { navigate: (section: SectionKey) => void }) {
  const { width } = useWindowDimensions();
  const narrow = width < 760;
  return (
    <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
      <View style={[styles.hero, narrow && styles.heroNarrow]}>
        <View style={[styles.heroCopy, narrow && styles.heroCopyNarrow]}>
          <Eyebrow icon="sparkles">YOUR AI LEARNING COMPANION</Eyebrow>
          <Text style={[styles.heroTitle, narrow && styles.heroTitleNarrow]}>Learn Smarter.{"\n"}<Text style={styles.heroAccent}>Create More.</Text></Text>
          <Text style={styles.heroBody}>Your personal AI assistant for questions, study, coding, creativity and discovery.</Text>
          <View style={styles.heroActions}>
            <GlowButton onPress={() => navigate("chat")} icon="arrow-forward">Start Exploring</GlowButton>
            <GlowButton onPress={() => navigate("study")} icon="grid-outline" variant="outline">Explore Features</GlowButton>
          </View>
          <View style={styles.quickGrid}>
            <QuickAction icon="school-outline" color={palette.violet} title="AI Study Assistant" description="Get help with your studies, anytime." onPress={() => navigate("study")} />
            <QuickAction icon="globe-outline" color={palette.cyan} title="Multilingual Support" description="Ask in your language and get answers in yours." onPress={() => navigate("chat")} />
            <QuickAction icon="sparkles-outline" color={palette.magenta} title="Creative Tools" description="Generate images, ideas and more." onPress={() => navigate("create")} />
          </View>
        </View>
        <View style={[styles.heroArt, narrow && styles.heroArtNarrow]}><NeuralHeroArt compact={narrow} /></View>
      </View>

      <SectionTitle eyebrow="FEATURES" title="Everything You Need to Learn" description="One intelligent platform for learning, creativity and discovery." />
      <View style={styles.featureGrid}>
        <FeatureCard icon="chatbubbles-outline" color={palette.magenta} title="Neuro Chat" description="Ask anything and get instant, clear explanations." onPress={() => navigate("chat")} />
        <FeatureCard icon="book-outline" color={palette.cyan} title="Study Assistant" description="Summaries, notes, quizzes and revision material." onPress={() => navigate("study")} />
        <FeatureCard icon="image-outline" color={palette.violet} title="AI Image Studio" description="Turn ideas into visual learning and creative art." onPress={() => navigate("image")} />
        <FeatureCard icon="library-outline" color={palette.cyan} title="Neuro Library" description="Browse books, save your reading list and explore." onPress={() => navigate("library")} />
        <FeatureCard icon="layers-outline" color={palette.magenta} title="CreateLab" description="One prompt into many useful student resources." onPress={() => navigate("create")} />
        <FeatureCard icon="code-slash-outline" color={palette.violet} title="Coding Help" description="Understand code, debug errors and build confidently." onPress={() => navigate("coding")} />
      </View>
      <View style={styles.missionStrip}><NeuroMark size={38} /><View style={{ flex: 1 }}><Text style={styles.missionTitle}>Knowledge for Everyone.</Text><Text style={styles.missionText}>Learn. Explore. Imagine. Create.</Text></View><StatusDot label="Student-first platform" /></View>
    </ScrollView>
  );
}

function FeatureCard({ icon, color, title, description, onPress }: { icon: IconName; color: string; title: string; description: string; onPress: () => void }) {
  return <GlassCard accent={color === palette.violet ? "violet" : color === palette.cyan ? "cyan" : "blue"} style={styles.featureCard}><IconBubble icon={icon} color={color} size={48} /><Text style={styles.featureTitle}>{title}</Text><Text style={styles.featureDescription}>{description}</Text><Pressable onPress={onPress} style={styles.circleArrow}><Ionicons name="arrow-forward" size={16} color={palette.cyan} /></Pressable></GlassCard>;
}

function ChatScreen({ preferences, chats, setChats }: { preferences: NeuroPreferences; chats: ChatMessage[]; setChats: (value: ChatMessage[]) => void }) {
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const [searchWeb, setSearchWeb] = useState(false);
  const visible = chats.length ? chats : [{ id: "welcome", role: "assistant" as const, content: "Hello! I’m Neuro AI. Ask me anything about your studies, code or ideas — I’ll explain it in a way that matches your language.", createdAt: 0 }];
  async function send() {
    const value = input.trim();
    if (!value || loading) return;
    const user: ChatMessage = { id: `${Date.now()}-u`, role: "user", content: value, createdAt: Date.now() };
    const next = [...(chats.length ? chats : []), user];
    setChats(next); setInput(""); setLoading(true); setStatus("");
    try {
      const response = await askNeuro(next, { language: preferences.language, answerStyle: preferences.answerStyle, searchWeb });
      const assistant: ChatMessage = { id: `${Date.now()}-a`, role: "assistant", content: response.content, createdAt: Date.now() };
      setChats([...next, assistant]);
    } catch (error) {
      setStatus(error instanceof NeuroApiError ? error.message : "The AI service is unavailable. Your question is safe — please retry.");
    } finally { setLoading(false); }
  }
  function clearChat() { confirmAction("Delete this conversation?", () => { setChats([]); setStatus("Conversation cleared."); }); }
  return <ScrollView contentContainerStyle={styles.scrollContent} keyboardShouldPersistTaps="handled"><SectionTitle eyebrow="NEURO CHAT" title="Ask. Understand. Grow." description="A multilingual AI learning companion for questions, study, coding and discovery." action={<GlowButton variant="outline" icon="add" onPress={() => setChats([])}>New chat</GlowButton>} />
    <View style={styles.chatLayout}><View style={{ flex: 1 }}><GlassCard style={styles.chatPanel} accent="cyan"><View style={styles.panelHeader}><View><Text style={styles.panelTitle}>Neuro Chat</Text><StatusDot label="Ready to help" /></View><Pressable onPress={clearChat}><Ionicons name="trash-outline" size={19} color={palette.danger} /></Pressable></View><View style={styles.chatMessages}>{visible.map((message) => <View key={message.id} style={[styles.messageRow, message.role === "user" && { justifyContent: "flex-end" }]}><View style={[styles.messageBubble, message.role === "user" ? styles.userBubble : styles.assistantBubble]}><Text style={styles.messageRole}>{message.role === "user" ? "YOU" : "NEURO AI"} · {formatTime(message.createdAt)}</Text><Text style={styles.messageText}>{message.content}</Text>{message.role === "assistant" ? <Pressable onPress={() => copyText(message.content)} style={styles.inlineAction}><Ionicons name="copy-outline" size={14} color={palette.cyan} /><Text style={styles.inlineActionText}>Copy answer</Text></Pressable> : null}</View></View>)}{loading ? <View style={styles.messageRow}><View style={styles.assistantBubble}><ActivityIndicator color={palette.cyan} /><Text style={styles.thinking}>Neuro is thinking…</Text></View></View> : null}</View>{status ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={17} color={palette.warning} /><Text style={styles.errorText}>{status}</Text></View> : null}<Pressable onPress={() => setSearchWeb((value) => !value)} style={[styles.toolChip, searchWeb && styles.toolChipActive, { alignSelf: "flex-start", marginTop: 12, marginBottom: 8, flexDirection: "row", alignItems: "center", gap: 7 }]}><Ionicons name="globe-outline" size={15} color={searchWeb ? palette.text : palette.cyan} /><Text style={[styles.toolChipText, searchWeb && { color: palette.text }]}>{searchWeb ? "Web search ON · sourced answers" : "Enable live web search"}</Text></Pressable><View style={styles.composer}><TextInput value={input} onChangeText={setInput} placeholder="Ask Neuro anything…" placeholderTextColor={palette.subtle} multiline onSubmitEditing={() => send()} style={styles.composerInput} /><Pressable onPress={send} style={styles.sendButton}><Ionicons name="arrow-up" size={20} color="#06112B" /></Pressable></View><Text style={styles.helperText}>Enter to send · Shift + Enter for a new line · Web search uses Google Search grounding when enabled.</Text></GlassCard><VoiceAssistantPanel language={preferences.language} latestAnswer={[...visible].reverse().find((message) => message.role === "assistant")?.content || ""} onTranscript={setInput} /></View></View></ScrollView>;
}

const studyTools = ["Topic Explainer", "Notes Generator", "Chapter Summarizer", "MCQ Generator", "Quiz Creator", "Flashcard Generator", "Revision Planner", "Viva Preparation", "Presentation Outline Generator", "Assignment Planning Assistant"];

function GenerationCard({ title, value, onCopy, onShare }: { title: string; value: string; onCopy: () => void; onShare: () => void }) {
  return <GlassCard accent="violet" style={{ marginTop: 18 }}><View style={styles.panelHeader}><Text style={styles.panelTitle}>{title}</Text><View style={styles.inlineActions}><Pressable onPress={onCopy} style={styles.iconAction}><Ionicons name="copy-outline" size={16} color={palette.cyan} /></Pressable><Pressable onPress={onShare} style={styles.iconAction}><Ionicons name="share-social-outline" size={16} color={palette.cyan} /></Pressable></View></View><Text style={styles.resultText}>{value}</Text></GlassCard>;
}

function StudyScreen({ preferences }: { preferences: NeuroPreferences }) {
  const [tool, setTool] = useState(studyTools[0]); const [topic, setTopic] = useState(""); const [subject, setSubject] = useState(""); const [level, setLevel] = useState(""); const [length, setLength] = useState("Simple"); const [result, setResult] = useState(""); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function generate() { if (!topic.trim() || loading) return; setLoading(true); setError(""); setResult(""); try { const response = await askNeuro([{ id: "study", role: "user", content: `${tool}: Create a ${length.toLowerCase()} educational response for topic ${topic}, subject ${subject || "general"}, class level ${level || "student"}. Include clear headings and practical examples.`, createdAt: Date.now() }], { language: preferences.language, answerStyle: length }); setResult(response.content); } catch (e) { setError(e instanceof NeuroApiError ? e.message : "Study generation is unavailable right now."); } finally { setLoading(false); } }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="STUDY TOOLS" title="Make every lesson clearer." description="Choose a tool, add your context and create focused revision material." /><View style={styles.toolWrap}>{studyTools.map((name) => <Pressable key={name} onPress={() => setTool(name)} style={[styles.toolChip, tool === name && styles.toolChipActive]}><Text style={[styles.toolChipText, tool === name && { color: palette.text }]}>{name}</Text></Pressable>)}</View><GlassCard accent="cyan"><Text style={styles.panelTitle}>{tool}</Text><TextInput value={topic} onChangeText={setTopic} placeholder="Topic or chapter…" placeholderTextColor={palette.subtle} style={styles.input} /><View style={styles.twoInputs}><TextInput value={subject} onChangeText={setSubject} placeholder="Subject" placeholderTextColor={palette.subtle} style={[styles.input, { flex: 1 }]} /><TextInput value={level} onChangeText={setLevel} placeholder="Class level" placeholderTextColor={palette.subtle} style={[styles.input, { flex: 1 }]} /></View><View style={styles.optionRow}><Text style={styles.optionLabel}>Explanation length</Text><Pressable onPress={() => setLength(length === "Simple" ? "Detailed" : "Simple")} style={styles.selectPill}><Text style={styles.selectPillText}>{length}</Text><Ionicons name="chevron-down" size={15} color={palette.cyan} /></Pressable></View><GlowButton onPress={generate} icon="sparkles" disabled={!topic.trim() || loading}>{loading ? "Generating…" : `Generate ${tool}`}</GlowButton>{error ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={17} color={palette.warning} /><Text style={styles.errorText}>{error}</Text></View> : null}</GlassCard>{result ? <GenerationCard title="Your learning material" value={result} onCopy={() => copyText(result)} onShare={() => shareText(tool, result)} /> : null}<Text style={styles.disclaimer}>AI-generated educational content can contain mistakes. Check important facts with your teacher or trusted sources.</Text></ScrollView>;
}

function ImageStudioScreen() {
  const [prompt, setPrompt] = useState(""); const [negative, setNegative] = useState(""); const [style, setStyle] = useState("Futuristic"); const [ratio, setRatio] = useState("1:1"); const [loading, setLoading] = useState(false); const [error, setError] = useState(""); const [image, setImage] = useState("");
  async function generate() { if (!prompt.trim() || loading) return; setLoading(true); setError(""); setImage(""); try { const result = await generateNeuroImage({ prompt, negativePrompt: negative, style, aspectRatio: ratio }); setImage(result.url || (result.b64Json ? `data:${result.mimeType || "image/png"};base64,${result.b64Json}` : "")); if (!result.url && !result.b64Json) setError("The image service returned no usable preview."); } catch (e) { setError(e instanceof NeuroApiError ? e.message : "Image generation is unavailable right now."); } finally { setLoading(false); } }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="AI IMAGE STUDIO" title="Turn ideas into visuals." description="Create futuristic art, diagrams and educational images with honest generation status." /><GlassCard accent="violet"><Text style={styles.panelTitle}>Describe your image</Text><TextInput value={prompt} onChangeText={setPrompt} placeholder="A glowing 3D model of the solar system…" placeholderTextColor={palette.subtle} multiline style={[styles.input, styles.textArea]} /><TextInput value={negative} onChangeText={setNegative} placeholder="Optional negative prompt" placeholderTextColor={palette.subtle} style={styles.input} /><Text style={styles.fieldLabel}>Style</Text><View style={styles.toolWrap}>{["Realistic", "Illustration", "3D", "Educational diagram", "Futuristic", "Cartoon", "Digital art"].map((item) => <Pressable key={item} onPress={() => setStyle(item)} style={[styles.toolChip, style === item && styles.toolChipActive]}><Text style={[styles.toolChipText, style === item && { color: palette.text }]}>{item}</Text></Pressable>)}</View><Text style={styles.fieldLabel}>Aspect ratio</Text><View style={styles.toolWrap}>{["1:1", "16:9", "4:3", "9:16"].map((item) => <Pressable key={item} onPress={() => setRatio(item)} style={[styles.toolChip, ratio === item && styles.toolChipActive]}><Text style={[styles.toolChipText, ratio === item && { color: palette.text }]}>{item}</Text></Pressable>)}</View><GlowButton onPress={generate} icon="sparkles" disabled={!prompt.trim() || loading}>{loading ? "Creating preview…" : "Generate image"}</GlowButton>{error ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={17} color={palette.warning} /><Text style={styles.errorText}>{error}</Text></View> : null}</GlassCard>{image ? <GlassCard accent="cyan" style={{ marginTop: 18 }}><View style={styles.panelHeader}><Text style={styles.panelTitle}>Generated preview</Text><GlowButton variant="outline" onPress={() => Linking.openURL(image)} icon="download-outline">Download</GlowButton></View><Image source={{ uri: image }} style={styles.generatedImage} resizeMode="contain" /><GlowButton variant="outline" onPress={generate} icon="refresh">Regenerate</GlowButton></GlassCard> : <View style={styles.emptyStudio}><NeuralHeroArt compact /><Text style={styles.emptyTitle}>Your visual will appear here</Text><Text style={styles.emptyText}>Generation requires a connected image service. Failed requests stay visible and can be retried.</Text></View>}</ScrollView>;
}

function LibraryScreen({ reading, setReading }: { reading: Record<string, "Want to Read" | "Reading" | "Completed">; setReading: (value: Record<string, "Want to Read" | "Reading" | "Completed">) => void }) {
  const [query, setQuery] = useState(""); const [subject, setSubject] = useState("All");
  const filtered = books.filter((book) => `${book.title} ${book.author}`.toLowerCase().includes(query.toLowerCase()) && (subject === "All" || book.subject === subject));
  function cycle(book: Book) { const current = reading[book.id]; const next = !current ? "Want to Read" : current === "Want to Read" ? "Reading" : current === "Reading" ? "Completed" : undefined; const updated = { ...reading }; if (next) updated[book.id] = next; else delete updated[book.id]; setReading(updated); }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="NEURO LIBRARY" title="Read. Discover. Remember." description="Browse learning and literature picks, then keep your own reading journey." /><View style={styles.searchBox}><Ionicons name="search" size={18} color={palette.subtle} /><TextInput value={query} onChangeText={setQuery} placeholder="Search title or author" placeholderTextColor={palette.subtle} style={styles.searchInput} /></View><View style={styles.toolWrap}>{["All", "Science", "History", "Productivity", "Literature"].map((item) => <Pressable key={item} onPress={() => setSubject(item)} style={[styles.toolChip, subject === item && styles.toolChipActive]}><Text style={[styles.toolChipText, subject === item && { color: palette.text }]}>{item}</Text></Pressable>)}</View><View style={styles.bookGrid}>{filtered.map((book) => <GlassCard key={book.id} accent={book.subject === "Science" ? "cyan" : "violet"} style={styles.bookCard}><View style={[styles.bookCover, { backgroundColor: book.cover }]}><Text style={styles.coverNeuro}>N</Text><Text style={styles.coverSubject}>{book.subject}</Text></View><Text style={styles.bookTitle}>{book.title}</Text><Text style={styles.bookAuthor}>{book.author}</Text><Text style={styles.bookDescription}>{book.description}</Text><Pressable onPress={() => cycle(book)} style={styles.readingStatus}><Text style={styles.readingStatusText}>{reading[book.id] || "Add to reading list"}</Text><Ionicons name="chevron-forward" size={15} color={palette.cyan} /></Pressable><Pressable onPress={() => Linking.openURL(`https://openlibrary.org/search?q=${encodeURIComponent(book.title)}`)}><Text style={styles.openLibrary}>View on Open Library ↗</Text></Pressable></GlassCard>)}</View>{filtered.length === 0 ? <Text style={styles.emptyText}>No books match this search yet.</Text> : null}</ScrollView>;
}

const createTypes = ["Project Ideas", "Presentation Outlines", "Report Drafts", "Poster Concepts", "Website Starter Code", "Practice Quizzes", "Study Guides", "Viva Questions", "Creative Writing", "Educational Explanations"];
function CreateLabScreen({ preferences }: { preferences: NeuroPreferences }) {
  const [type, setType] = useState(createTypes[0]); const [prompt, setPrompt] = useState(""); const [result, setResult] = useState(""); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function create() { if (!prompt.trim() || loading) return; setLoading(true); setError(""); try { const response = await askNeuro([{ id: "create", role: "user", content: `Create a ${type} for this student request: ${prompt}. Organize the answer with useful headings and practical next steps.`, createdAt: Date.now() }], { language: preferences.language, answerStyle: preferences.answerStyle }); setResult(response.content); } catch (e) { setError(e instanceof NeuroApiError ? e.message : "CreateLab is unavailable right now."); } finally { setLoading(false); } }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="NEURO CREATELAB" title="One Prompt. Multiple Possibilities." description="Turn one idea into an outline, guide, draft, quiz or creative starting point." /><View style={styles.toolWrap}>{createTypes.map((item) => <Pressable key={item} onPress={() => setType(item)} style={[styles.toolChip, type === item && styles.toolChipActive]}><Text style={[styles.toolChipText, type === item && { color: palette.text }]}>{item}</Text></Pressable>)}</View><GlassCard accent="violet"><Text style={styles.panelTitle}>{type}</Text><TextInput value={prompt} onChangeText={setPrompt} placeholder="Tell Neuro what you want to create…" placeholderTextColor={palette.subtle} style={[styles.input, styles.textArea]} /><GlowButton onPress={create} icon="sparkles" disabled={!prompt.trim() || loading}>{loading ? "Creating…" : `Create ${type}`}</GlowButton>{error ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={17} color={palette.warning} /><Text style={styles.errorText}>{error}</Text></View> : null}</GlassCard>{result ? <GenerationCard title={type} value={result} onCopy={() => copyText(result)} onShare={() => shareText(type, result)} /> : null}</ScrollView>;
}

function CodingScreen({ preferences }: { preferences: NeuroPreferences }) {
  const [language, setLanguage] = useState("Python"); const [prompt, setPrompt] = useState(""); const [result, setResult] = useState(""); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  async function explain() { if (!prompt.trim() || loading) return; setLoading(true); setError(""); try { const response = await askNeuro([{ id: "coding", role: "user", content: `You are Coding Help. Explain and solve this ${language} question for a student: ${prompt}. Include purpose, readable code, how to run it and a beginner-friendly explanation. Never execute code.`, createdAt: Date.now() }], { language: preferences.language, answerStyle: "Detailed" }); setResult(response.content); } catch (e) { setError(e instanceof NeuroApiError ? e.message : "Coding Help is unavailable right now."); } finally { setLoading(false); } }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="CODING HELP" title="Build with understanding." description="Ask about HTML, CSS, JavaScript, Python, responsive layouts, debugging and optimization." /><GlassCard accent="cyan"><Text style={styles.fieldLabel}>Language</Text><View style={styles.toolWrap}>{["HTML", "CSS", "JavaScript", "Python"].map((item) => <Pressable key={item} onPress={() => setLanguage(item)} style={[styles.toolChip, language === item && styles.toolChipActive]}><Text style={[styles.toolChipText, language === item && { color: palette.text }]}>{item}</Text></Pressable>)}</View><TextInput value={prompt} onChangeText={setPrompt} placeholder="Paste an error or describe what you want to build…" placeholderTextColor={palette.subtle} multiline style={[styles.input, styles.textArea]} /><GlowButton onPress={explain} icon="code-slash" disabled={!prompt.trim() || loading}>{loading ? "Explaining…" : "Explain and help"}</GlowButton>{error ? <View style={styles.errorBox}><Ionicons name="alert-circle-outline" size={17} color={palette.warning} /><Text style={styles.errorText}>{error}</Text></View> : null}</GlassCard>{result ? <GenerationCard title={`${language} guidance`} value={result} onCopy={() => copyText(result)} onShare={() => shareText("Coding Help", result)} /> : null}<GlassCard accent="violet" style={{ marginTop: 18 }}><Text style={styles.panelTitle}>Safe coding promise</Text><Text style={styles.bodyText}>Neuro AI explains code and how to run it, but never executes arbitrary code on the server. Always review code before using it.</Text></GlassCard></ScrollView>;
}

function AboutScreen({ navigate }: { navigate: (section: SectionKey) => void }) {
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="ABOUT NEURO AI" title="Technology for student empowerment." description="Neuro AI by Saravers is an educational AI platform designed to help students explore knowledge, understand difficult concepts, practice coding, discover books and express creativity through intelligent digital tools." /><View style={styles.aboutGrid}><GlassCard accent="cyan" style={styles.aboutCard}><IconBubble icon="rocket-outline" color={palette.cyan} /><Text style={styles.panelTitle}>Our mission</Text><Text style={styles.bodyText}>To make learning more accessible, interactive and inspiring for students.</Text></GlassCard><GlassCard accent="violet" style={styles.aboutCard}><IconBubble icon="heart-outline" color={palette.violet} /><Text style={styles.panelTitle}>Our values</Text><Text style={styles.bodyText}>Accessible Learning · Creativity · Technology for Education · Student Empowerment · Responsible AI.</Text></GlassCard></View><GlassCard accent="violet" style={{ marginTop: 18 }}><Text style={styles.panelTitle}>Neuro Robot — future integration</Text><Text style={styles.bodyText}>Demo mode is available as an architecture concept. A future robot can receive answers through configurable audio and movement modules, but physical Bluetooth, USB or motor integration is not claimed until tested with compatible hardware.</Text><View style={styles.robotRow}><StatusDot label="Simulation mode" tone="warning" /><GlowButton variant="outline" onPress={() => navigate("settings")} icon="settings-outline">Open settings</GlowButton></View></GlassCard><GlassCard accent="blue" style={{ marginTop: 18 }}><Text style={styles.panelTitle}>Developer recognition</Text><Text style={styles.bodyText}>Developed by Sara Abdul Latif{`\n`}Saravers Team{`\n`}An educational AI project associated with Government Girls Higher Secondary School, Ghotki.</Text><Text style={styles.disclaimer}>The app does not imply official institutional endorsement without permission.</Text></GlassCard></ScrollView>;
}

function SettingsScreen({ preferences, setPreferences, clearData }: { preferences: NeuroPreferences; setPreferences: (value: NeuroPreferences) => void; clearData: () => void }) {
  function update(patch: Partial<NeuroPreferences>) { const next = { ...preferences, ...patch }; setPreferences(next); savePreferences(next); }
  return <ScrollView contentContainerStyle={styles.scrollContent}><SectionTitle eyebrow="MAKE IT MY WAY" title="Settings that fit your learning." description="Personalize language, answer depth, voice and privacy without storing sensitive credentials." /><GlassCard accent="cyan"><SettingRow icon="language-outline" title="Preferred language" description="The assistant can still follow the language you use."><Pressable onPress={() => update({ language: preferences.language === "Follow my language" ? "English" : preferences.language === "English" ? "Urdu" : preferences.language === "Urdu" ? "Roman Urdu" : "Follow my language" })} style={styles.selectPill}><Text style={styles.selectPillText}>{preferences.language}</Text><Ionicons name="chevron-down" size={15} color={palette.cyan} /></Pressable></SettingRow><SettingRow icon="text-outline" title="Answer style" description="Choose a quick explanation or deeper lesson."><Pressable onPress={() => update({ answerStyle: preferences.answerStyle === "Simple" ? "Detailed" : "Simple" })} style={styles.selectPill}><Text style={styles.selectPillText}>{preferences.answerStyle}</Text><Ionicons name="chevron-down" size={15} color={palette.cyan} /></Pressable></SettingRow><SettingRow icon="volume-high-outline" title="Voice playback" description="Enable a playback preference for future voice responses."><Switch value={preferences.voicePlayback} onValueChange={(value) => update({ voicePlayback: value })} trackColor={{ false: palette.border, true: palette.violet }} thumbColor={palette.cyan} /></SettingRow><SettingRow icon="color-palette-outline" title="Theme" description="The reference experience is a dark futuristic study space."><StatusDot label="Dark neon glass" /></SettingRow></GlassCard><GlassCard accent="violet" style={{ marginTop: 18 }}><Text style={styles.panelTitle}>Privacy and history</Text><Text style={styles.bodyText}>API keys and passwords are never stored in app storage. Chat and reading preferences are saved locally on this device for the prototype.</Text><GlowButton variant="outline" onPress={() => confirmAction("Clear local chat and reading history?", clearData)} icon="trash-outline">Clear local history</GlowButton></GlassCard></ScrollView>;
}

function SettingRow({ icon, title, description, children }: { icon: IconName; title: string; description: string; children: ReactNode }) {
  return <View style={styles.settingRow}><IconBubble icon={icon} color={palette.cyan} size={38} /><View style={{ flex: 1 }}><Text style={styles.settingTitle}>{title}</Text><Text style={styles.settingDescription}>{description}</Text></View>{children}</View>;
}

export default function NeuroApp() {
  const insets = useSafeAreaInsets();
  const { width } = useWindowDimensions();
  const [active, setActive] = useState<SectionKey>("home");
  const [preferences, setPreferences] = useState<NeuroPreferences>(defaultPreferences);
  const [chats, setChats] = useState<ChatMessage[]>([]);
  const [reading, setReading] = useState<Record<string, "Want to Read" | "Reading" | "Completed">>({});
  const wide = width >= 980;
  useEffect(() => { loadPreferences().then(setPreferences); loadChats().then(setChats); loadReadingList().then(setReading); }, []);
  function updateChats(value: ChatMessage[]) { setChats(value); saveChats(value); }
  function updateReading(value: Record<string, "Want to Read" | "Reading" | "Completed">) { setReading(value); saveReadingList(value); }
  function clearData() { setChats([]); setReading({}); AsyncStorage.multiRemove(["neuroai.chats", "neuroai.reading"]); }
  const page = useMemo(() => {
    if (active === "home") return <HomeScreen navigate={setActive} />;
    if (active === "chat") return <ChatScreen preferences={preferences} chats={chats} setChats={updateChats} />;
    if (active === "study") return <StudyScreen preferences={preferences} />;
    if (active === "image") return <ImageStudioScreen />;
    if (active === "library") return <LibraryScreen reading={reading} setReading={updateReading} />;
    if (active === "create") return <CreateLabScreen preferences={preferences} />;
    if (active === "coding") return <CodingScreen preferences={preferences} />;
    if (active === "about") return <AboutScreen navigate={setActive} />;
    if (active === "login") return <AdminLoginScreen />;
    return <SettingsScreen preferences={preferences} setPreferences={setPreferences} clearData={clearData} />;
  }, [active, preferences, chats, reading]);
  return <View style={[styles.app, { paddingTop: Math.max(insets.top, 10) }]}><BrandHeader active={active} onNavigate={setActive} onGetStarted={() => setActive("chat")} /><View style={[styles.body, wide && styles.bodyWide]}>{page}</View>{!wide ? <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.bottomNav}>{navItems.slice(0, 7).map((item) => <NavButton key={item.key} item={item} active={active} onPress={() => setActive(item.key)} />)}</ScrollView> : null}<View style={styles.footer}><NeuroMark size={28} /><Text style={styles.footerText}>NEURO AI · Knowledge for Everyone · © {new Date().getFullYear()} Saravers</Text></View></View>;
}

const styles = StyleSheet.create({
  app: { flex: 1, backgroundColor: palette.bg },
  header: { minHeight: 76, borderBottomWidth: 1, borderBottomColor: "#18275A", paddingHorizontal: 22, flexDirection: "row", alignItems: "center", justifyContent: "space-between", zIndex: 5 },
  brand: { flexDirection: "row", alignItems: "center", gap: 10 },
  brandTitle: { color: palette.text, fontSize: 21, fontWeight: "900", letterSpacing: 1.2 },
  brandSub: { color: palette.cyan, fontSize: 9, letterSpacing: 1.8, fontWeight: "800", marginTop: 2 },
  desktopNav: { flexDirection: "row", alignItems: "center", gap: 2 },
  navButton: { height: 38, minHeight: 38, paddingHorizontal: 9, borderRadius: 999, flexDirection: "row", gap: 6, alignItems: "center", justifyContent: "center" },
  navButtonActive: { backgroundColor: "#17245A", borderBottomWidth: 2, borderBottomColor: palette.cyan },
  navText: { color: palette.muted, fontSize: 12, fontWeight: "700" },
  menuButton: { padding: 10, borderRadius: 12, backgroundColor: "#111A49" },
  mobileMenu: { position: "absolute", top: 68, left: 12, right: 12, backgroundColor: "#091334F5", borderWidth: 1, borderColor: palette.border, borderRadius: 18, padding: 12, gap: 5, shadowColor: "#000", shadowOpacity: 0.4, shadowRadius: 16, elevation: 8 },
  body: { flex: 1 },
  bodyWide: { maxWidth: 1440, width: "100%", alignSelf: "center" },
  scrollContent: { paddingHorizontal: 22, paddingVertical: 28, paddingBottom: 46, maxWidth: 1440, width: "100%", alignSelf: "center" },
  hero: { minHeight: 510, flexDirection: "row", alignItems: "center", gap: 20, paddingVertical: 28 },
  heroNarrow: { minHeight: 0, flexDirection: "column", alignItems: "stretch", gap: 6 },
  heroCopy: { flex: 1, maxWidth: 700 },
  heroCopyNarrow: { maxWidth: "100%" },
  heroArt: { flex: 1, alignItems: "center", justifyContent: "center", minWidth: 320 },
  heroArtNarrow: { minWidth: 0, width: "100%", marginTop: 8 },
  heroTitle: { color: palette.text, fontSize: 58, lineHeight: 62, fontWeight: "900", letterSpacing: -2, marginTop: 22 },
  heroTitleNarrow: { fontSize: 43, lineHeight: 47, letterSpacing: -1.5 },
  heroAccent: { color: palette.violet },
  heroBody: { color: palette.muted, fontSize: 17, lineHeight: 26, maxWidth: 560, marginTop: 17 },
  heroActions: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginTop: 26 },
  quickGrid: { flexDirection: "row", flexWrap: "wrap", gap: 1, marginTop: 40, borderWidth: 1, borderColor: "#263B85", backgroundColor: "#0A1538B8", borderRadius: 18, padding: 9 },
  quickAction: { flex: 1, minWidth: 180, flexDirection: "row", alignItems: "center", gap: 11, padding: 10 },
  quickTitle: { color: palette.text, fontWeight: "800", fontSize: 13 },
  quickDescription: { color: palette.muted, fontSize: 11, lineHeight: 16, marginTop: 2 },
  featureGrid: { flexDirection: "row", flexWrap: "wrap", gap: 16 },
  featureCard: { flexGrow: 1, flexBasis: 230, minHeight: 198 },
  featureTitle: { color: palette.text, fontSize: 17, fontWeight: "800", marginTop: 17 },
  featureDescription: { color: palette.muted, fontSize: 13, lineHeight: 19, marginTop: 7, flex: 1 },
  circleArrow: { width: 29, height: 29, borderRadius: 16, alignItems: "center", justifyContent: "center", borderWidth: 1, borderColor: palette.border, marginTop: 13 },
  missionStrip: { marginTop: 32, padding: 15, borderTopWidth: 1, borderBottomWidth: 1, borderColor: "#1D2A62", flexDirection: "row", alignItems: "center", gap: 12 },
  missionTitle: { color: palette.text, fontSize: 16, fontWeight: "800" },
  missionText: { color: palette.muted, fontSize: 12, marginTop: 3 },
  chatLayout: { flexDirection: "row" },
  chatPanel: { flex: 1, minHeight: 560 },
  panelHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: 15 },
  panelTitle: { color: palette.text, fontSize: 18, fontWeight: "800" },
  chatMessages: { gap: 12, minHeight: 350 },
  messageRow: { flexDirection: "row", width: "100%" },
  messageBubble: { maxWidth: "88%", padding: 14, borderRadius: 16, borderWidth: 1 },
  assistantBubble: { backgroundColor: "#111D4B", borderColor: "#2A438E", borderTopLeftRadius: 4 },
  userBubble: { backgroundColor: "#17377A", borderColor: "#2B9DCE", borderTopRightRadius: 4 },
  messageRole: { color: palette.cyan, fontSize: 10, fontWeight: "800", letterSpacing: 1.2, marginBottom: 7 },
  messageText: { color: palette.text, fontSize: 14, lineHeight: 21 },
  inlineAction: { flexDirection: "row", alignItems: "center", gap: 5, marginTop: 10 },
  inlineActionText: { color: palette.cyan, fontSize: 11, fontWeight: "700" },
  thinking: { color: palette.muted, fontSize: 12, marginTop: 8 },
  composer: { flexDirection: "row", alignItems: "flex-end", gap: 10, marginTop: 14, borderWidth: 1, borderColor: palette.border, backgroundColor: "#071131", borderRadius: 16, padding: 8 },
  composerInput: { flex: 1, color: palette.text, fontSize: 14, minHeight: 42, maxHeight: 120, paddingHorizontal: 9, paddingTop: 10 },
  sendButton: { width: 40, height: 40, borderRadius: 20, backgroundColor: palette.cyan, alignItems: "center", justifyContent: "center" },
  helperText: { color: palette.subtle, fontSize: 11, marginTop: 9 },
  errorBox: { flexDirection: "row", gap: 8, alignItems: "flex-start", backgroundColor: "#3A2D20", borderWidth: 1, borderColor: "#9B6B36", borderRadius: 12, padding: 11, marginTop: 12 },
  errorText: { color: "#FFD69C", fontSize: 12, lineHeight: 18, flex: 1 },
  toolWrap: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 17 },
  toolChip: { borderWidth: 1, borderColor: palette.border, borderRadius: 999, paddingHorizontal: 12, paddingVertical: 9, backgroundColor: "#0B1539" },
  toolChipActive: { backgroundColor: "#2A286B", borderColor: palette.violet },
  toolChipText: { color: palette.muted, fontSize: 12, fontWeight: "700" },
  input: { borderWidth: 1, borderColor: palette.border, backgroundColor: "#071131", color: palette.text, borderRadius: 12, minHeight: 45, paddingHorizontal: 13, fontSize: 14, marginTop: 12 },
  textArea: { minHeight: 120, textAlignVertical: "top", paddingTop: 12 },
  twoInputs: { flexDirection: "row", gap: 10 },
  optionRow: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", marginVertical: 15 },
  optionLabel: { color: palette.muted, fontSize: 13 },
  selectPill: { flexDirection: "row", alignItems: "center", gap: 6, borderWidth: 1, borderColor: palette.border, borderRadius: 999, paddingHorizontal: 11, paddingVertical: 8 },
  selectPillText: { color: palette.text, fontSize: 12, fontWeight: "700" },
  disclaimer: { color: palette.subtle, fontSize: 12, lineHeight: 18, marginTop: 14 },
  inlineActions: { flexDirection: "row", gap: 7 },
  iconAction: { width: 34, height: 34, borderRadius: 17, backgroundColor: "#11204C", alignItems: "center", justifyContent: "center" },
  resultText: { color: "#DCE4FF", fontSize: 14, lineHeight: 23 },
  fieldLabel: { color: palette.muted, fontSize: 12, fontWeight: "800", letterSpacing: 0.8, marginTop: 15, marginBottom: 8 },
  generatedImage: { width: "100%", height: 360, borderRadius: 14, backgroundColor: "#071131", marginBottom: 14 },
  emptyStudio: { alignItems: "center", paddingVertical: 20 },
  emptyTitle: { color: palette.text, fontSize: 17, fontWeight: "800", marginTop: 5 },
  emptyText: { color: palette.muted, fontSize: 13, lineHeight: 19, textAlign: "center", maxWidth: 420, marginTop: 7 },
  searchBox: { flexDirection: "row", alignItems: "center", gap: 8, backgroundColor: "#071131", borderWidth: 1, borderColor: palette.border, borderRadius: 12, paddingHorizontal: 12, marginBottom: 12 },
  searchInput: { flex: 1, color: palette.text, height: 46 },
  bookGrid: { flexDirection: "row", flexWrap: "wrap", gap: 16 },
  bookCard: { flexGrow: 1, flexBasis: 235, maxWidth: 420 },
  bookCover: { height: 145, borderRadius: 13, padding: 14, justifyContent: "space-between", marginBottom: 14, overflow: "hidden" },
  coverNeuro: { color: "#FFFFFF55", fontSize: 76, fontWeight: "900", alignSelf: "flex-end" },
  coverSubject: { color: "#FFFFFFCC", fontSize: 11, fontWeight: "800", letterSpacing: 1.5, textTransform: "uppercase" },
  bookTitle: { color: palette.text, fontSize: 18, fontWeight: "800" },
  bookAuthor: { color: palette.cyan, fontSize: 12, marginTop: 4 },
  bookDescription: { color: palette.muted, fontSize: 13, lineHeight: 19, marginTop: 9, minHeight: 40 },
  readingStatus: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", borderTopWidth: 1, borderTopColor: "#21336D", marginTop: 15, paddingTop: 12 },
  readingStatusText: { color: palette.text, fontSize: 12, fontWeight: "700" },
  openLibrary: { color: palette.cyan, fontSize: 11, marginTop: 13 },
  aboutGrid: { flexDirection: "row", flexWrap: "wrap", gap: 16 },
  aboutCard: { flexGrow: 1, flexBasis: 280 },
  bodyText: { color: palette.muted, fontSize: 14, lineHeight: 22, marginTop: 11 },
  robotRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 18, gap: 12 },
  settingRow: { flexDirection: "row", alignItems: "center", gap: 12, paddingVertical: 15, borderBottomWidth: 1, borderBottomColor: "#1D2A62" },
  settingTitle: { color: palette.text, fontSize: 14, fontWeight: "800" },
  settingDescription: { color: palette.muted, fontSize: 12, lineHeight: 17, marginTop: 3 },
  bottomNav: { position: "absolute", left: 0, right: 0, bottom: 48, height: 56, paddingHorizontal: 11, paddingVertical: 8, gap: 3, alignItems: "center", borderTopWidth: 1, borderBottomWidth: 1, borderBottomColor: "#18275A", borderTopColor: "#18275A", backgroundColor: "#07102EF5", zIndex: 10, elevation: 8 },
  footer: { minHeight: 48, borderTopWidth: 1, borderTopColor: "#18275A", paddingHorizontal: 22, flexDirection: "row", alignItems: "center", gap: 10 },
  footerText: { color: palette.subtle, fontSize: 11 },
});
