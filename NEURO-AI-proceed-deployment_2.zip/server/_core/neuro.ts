import type { Express, Request, Response } from "express";
import { randomBytes, timingSafeEqual } from "node:crypto";

const WINDOW_MS = 60_000;
const MAX_REQUESTS = 20;
const requestLog = new Map<string, { startedAt: number; count: number }>();
const adminSessions = new Map<string, number>();

function clientAllowed(req: Request) {
  const now = Date.now();
  const key = req.ip || "anonymous";
  // Periodically prune expired entries so this in-memory limiter cannot grow forever.
  if (requestLog.size > 5_000) {
    for (const [ip, entry] of requestLog) {
      if (now - entry.startedAt > WINDOW_MS) requestLog.delete(ip);
    }
  }
  const previous = requestLog.get(key);
  if (!previous || now - previous.startedAt > WINDOW_MS) {
    requestLog.set(key, { startedAt: now, count: 1 });
    return true;
  }
  previous.count += 1;
  return previous.count <= MAX_REQUESTS;
}

function platformConfig() {
  const apiUrl = process.env.MANUS_API_URL;
  const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) return null;
  return { apiUrl: apiUrl.replace(/\/$/, ""), apiKey };
}

function openAIConfig() {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) return null;
  return {
    apiKey,
    baseUrl: (process.env.OPENAI_BASE_URL || "https://api.openai.com/v1").replace(/\/$/, ""),
    model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
    imageModel: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1",
  };
}

async function openAIJson(path: string, body: unknown) {
  const config = openAIConfig();
  if (!config) throw new Error("OpenAI is not configured. Add OPENAI_API_KEY to the server environment.");
  const response = await fetch(`${config.baseUrl}${path}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${config.apiKey}`, "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(180_000),
  });
  const text = await response.text();
  let parsed: any = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  if (!response.ok) {
    const message = parsed?.error?.message || `OpenAI request failed (${response.status}).`;
    const error = new Error(message) as Error & { status?: number };
    error.status = response.status;
    throw error;
  }
  return parsed;
}

function responseText(payload: any): string {
  if (typeof payload?.output_text === "string" && payload.output_text.trim()) return payload.output_text.trim();
  const parts: string[] = [];
  for (const item of payload?.output || []) {
    if (item?.type !== "message") continue;
    for (const content of item.content || []) {
      if (content?.type === "output_text" && typeof content.text === "string") parts.push(content.text);
    }
  }
  return parts.join("\n\n").trim();
}

function responseSources(payload: any): Array<{ title?: string; url: string }> {
  const sources = new Map<string, { title?: string; url: string }>();
  for (const item of payload?.output || []) {
    for (const content of item?.content || []) {
      for (const annotation of content?.annotations || []) {
        if (annotation?.type === "url_citation" && typeof annotation.url === "string") {
          sources.set(annotation.url, { title: annotation.title, url: annotation.url });
        }
      }
    }
  }
  return [...sources.values()].slice(0, 8);
}


function geminiConfig() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  return {
    apiKey,
    model: process.env.GEMINI_MODEL || "gemini-2.5-flash",
    baseUrl: "https://generativelanguage.googleapis.com/v1beta",
  };
}

async function geminiGenerate(body: unknown) {
  const config = geminiConfig();
  if (!config) throw new Error("Free AI is not configured yet. Add GEMINI_API_KEY to the server environment.");
  const response = await fetch(`${config.baseUrl}/models/${config.model}:generateContent?key=${encodeURIComponent(config.apiKey)}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(120_000),
  });
  const raw = await response.text();
  let payload: any = null;
  try { payload = raw ? JSON.parse(raw) : null; } catch { payload = null; }
  if (!response.ok) {
    const detail = payload?.error?.message || `Gemini request failed (${response.status}).`;
    const error = new Error(detail) as Error & { status?: number };
    error.status = response.status;
    throw error;
  }
  return payload;
}

function geminiText(payload: any): string {
  return (payload?.candidates?.[0]?.content?.parts || [])
    .filter((part: any) => typeof part?.text === "string")
    .map((part: any) => part.text)
    .join("\n")
    .trim();
}

function normalizeGeminiContents(messages: Array<{ role: string; content: string }>) {
  const turns: Array<{ role: "user" | "model"; parts: Array<{ text: string }> }> = [];
  for (const message of messages) {
    const role = message.role === "assistant" ? "model" : "user";
    const previous = turns[turns.length - 1];
    // Gemini expects the conversation to begin with a user turn and alternating turns.
    if (!previous && role !== "user") continue;
    if (previous?.role === role) previous.parts[0].text += "\n\n" + message.content;
    else turns.push({ role, parts: [{ text: message.content }] });
  }
  return turns;
}

function geminiSources(payload: any): Array<{ title?: string; url: string }> {
  const chunks = payload?.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sources = new Map<string, { title?: string; url: string }>();
  for (const chunk of chunks) {
    const web = chunk?.web;
    if (typeof web?.uri === "string" && /^https?:\/\//i.test(web.uri)) {
      sources.set(web.uri, { title: typeof web.title === "string" ? web.title : undefined, url: web.uri });
    }
  }
  return [...sources.values()].slice(0, 8);
}

async function generateHuggingFaceImage(prompt: string, aspectRatio: string) {
  const token = process.env.HUGGINGFACE_API_TOKEN;
  if (!token) return null;
  const dimensions = aspectRatio === "9:16" ? [768, 1024] : aspectRatio === "16:9" ? [1024, 576] : aspectRatio === "4:3" ? [1024, 768] : [1024, 1024];
  const model = process.env.HUGGINGFACE_IMAGE_MODEL || "black-forest-labs/FLUX.1-schnell";
  const response = await fetch(`https://router.huggingface.co/hf-inference/models/${model}`, {
    method: "POST",
    headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", Accept: "image/png" },
    body: JSON.stringify({ inputs: prompt, parameters: { width: dimensions[0], height: dimensions[1] } }),
    signal: AbortSignal.timeout(180_000),
  });
  if (!response.ok) {
    const detail = (await response.text()).slice(0, 500);
    const error = new Error(`Image provider error (${response.status}): ${detail || response.statusText}`) as Error & { status?: number };
    error.status = response.status;
    throw error;
  }
  const contentType = response.headers.get("content-type") || "image/png";
  if (!contentType.startsWith("image/")) throw new Error("Image provider returned an unexpected response. Check your Hugging Face token and model access.");
  const bytes = Buffer.from(await response.arrayBuffer());
  return { b64Json: bytes.toString("base64"), mimeType: contentType, model };
}

function fail(res: Response, status: number, message: string) {
  res.status(status).json({ error: { message } });
}

function safeEqual(left: string, right: string) {
  const a = Buffer.from(left);
  const b = Buffer.from(right);
  return a.length === b.length && timingSafeEqual(a, b);
}

function adminCredentials() {
  const username = process.env.NEURO_ADMIN_USERNAME?.trim();
  const password = process.env.NEURO_ADMIN_PASSWORD;
  if (!username || !password) return null;

  // Never allow the sample values from .env.example to become production credentials.
  const placeholderPasswords = new Set([
    "replace-with-a-unique-random-password-at-least-16-characters",
    "change-this-to-a-long-random-password",
    "password",
    "admin",
  ]);
  if (placeholderPasswords.has(password.toLowerCase()) || password.length < 16) return null;

  return { username, password };
}

function adminToken(req: Request) {
  const header = req.header("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  const expiresAt = token ? adminSessions.get(token) : undefined;
  if (!expiresAt || expiresAt < Date.now()) {
    if (token) adminSessions.delete(token);
    return null;
  }
  return token;
}

async function platformJson(path: string, body: unknown) {
  const config = platformConfig();
  if (!config) throw new Error("AI services are not configured for this project yet.");
  const response = await fetch(`${config.apiUrl}${path}`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${config.apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(120_000),
  });
  const text = await response.text();
  let parsed: any = null;
  try { parsed = text ? JSON.parse(text) : null; } catch { parsed = null; }
  if (!response.ok) {
    const detail = parsed?.error?.message || parsed?.message || "The managed AI service rejected the request.";
    const error = new Error(detail);
    (error as Error & { status?: number }).status = response.status;
    throw error;
  }
  if (parsed?.error) throw new Error(parsed.error.message || "The managed AI service returned an error.");
  return parsed;
}

export function registerNeuroRoutes(app: Express) {
  app.use("/api/neuro", (_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
  });

  app.get("/api/neuro/auth/config", (_req, res) => {
    const credentials = adminCredentials();
    return res.json({ username: credentials?.username || "" });
  });

  // Safe diagnostics only: never return keys, tokens, or credential values to the browser.
  app.get("/api/neuro/status", (_req, res) => {
    const openAI = Boolean(openAIConfig());
    const gemini = Boolean(geminiConfig());
    const huggingFace = Boolean(process.env.HUGGINGFACE_API_TOKEN);
    const managedProvider = Boolean(platformConfig());
    return res.json({
      ok: true,
      services: {
        chat: openAI || gemini || managedProvider,
        webSearch: openAI || gemini,
        imageGeneration: openAI || huggingFace || managedProvider,
      },
      providers: {
        chat: openAI ? "openai" : gemini ? "gemini" : managedProvider ? "managed" : null,
        image: openAI ? "openai" : huggingFace ? "huggingface" : managedProvider ? "managed" : null,
      },
    });
  });

  app.post("/api/neuro/auth/login", (req, res) => {
    if (!clientAllowed(req)) return fail(res, 429, "Too many login attempts. Please wait a moment and try again.");
    const credentials = adminCredentials();
    if (!credentials) return fail(res, 503, "Admin login is not securely configured. Set a unique NEURO_ADMIN_PASSWORD with at least 16 characters; do not use the sample value.");
    const username = typeof req.body?.username === "string" ? req.body.username.trim().slice(0, 160) : "";
    const password = typeof req.body?.password === "string" ? req.body.password : "";
    if (!safeEqual(username, credentials.username) || !safeEqual(password, credentials.password)) return fail(res, 401, "Username or password is incorrect.");
    const token = randomBytes(32).toString("hex");
    adminSessions.set(token, Date.now() + 8 * 60 * 60 * 1000);
    return res.json({ token, expiresIn: 8 * 60 * 60 });
  });

  app.post("/api/neuro/auth/logout", (req, res) => {
    const token = adminToken(req);
    if (token) adminSessions.delete(token);
    return res.json({ ok: true });
  });

  app.post("/api/neuro/admin/edit", async (req, res) => {
    if (!adminToken(req)) return fail(res, 401, "Please log in as the Neuro AI admin first.");
    if (!clientAllowed(req)) return fail(res, 429, "Too many editor requests. Please wait a moment and try again.");
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim().slice(0, 5000) : "";
    if (!prompt) return fail(res, 400, "Describe the change you want to make first.");
    try {
      const plannerInstructions = "You are the authenticated Neuro AI admin change planner. Turn the admin's request into a safe, concrete change proposal for this educational app. Do not output secrets, arbitrary executable code, database deletion instructions or claims that the production app was changed. Include: requested change, affected screen(s), implementation steps, risks, and a manual approval note. If the request is unsafe, explain why and suggest a safe alternative.";
      const gemini = geminiConfig();
      const payload = openAIConfig()
        ? await openAIJson("/responses", { model: openAIConfig()!.model, instructions: plannerInstructions, input: prompt })
        : gemini
          ? await geminiGenerate({ systemInstruction: { parts: [{ text: plannerInstructions }] }, contents: [{ role: "user", parts: [{ text: prompt }] }] })
          : await platformJson("/v1/chat/completions", { messages: [{ role: "system", content: plannerInstructions }, { role: "user", content: prompt }], stream: false });
      const content = openAIConfig() ? responseText(payload) : gemini ? geminiText(payload) : payload?.choices?.[0]?.message?.content;
      if (!content || typeof content !== "string") return fail(res, 502, "The editor returned no usable change proposal.");
      return res.json({ proposal: content, note: "This is a reviewable proposal. It does not mutate source code or deploy automatically." });
    } catch (error: any) {
      return fail(res, error?.status && error.status >= 400 && error.status < 500 ? error.status : 502, error?.message || "The admin editor is unavailable right now.");
    }
  });

  app.post("/api/neuro/chat", async (req, res) => {
    if (!clientAllowed(req)) return fail(res, 429, "Too many requests. Please wait a moment and try again.");
    const rawMessages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const messages = rawMessages
      // The system prompt is server-owned; never accept client-supplied system instructions.
      .filter((item: any) => ["user", "assistant"].includes(item?.role) && typeof item?.content === "string")
      .slice(-24)
      .map((item: any) => ({ role: item.role, content: item.content.slice(0, 12_000) }));
    if (!messages.length || !messages.some((message: any) => message.role === "user")) return fail(res, 400, "Please enter a question first.");
    const language = typeof req.body?.language === "string" ? req.body.language.slice(0, 80) : "Follow the student's language";
    const answerStyle = req.body?.answerStyle === "Detailed" ? "Detailed" : "Simple";
    const system = `You are Neuro AI by Saravers, a patient educational assistant. Answer in the student's language when possible, including English, Urdu, Roman Urdu and Sindhi. Prefer ${answerStyle.toLowerCase()} explanations. Teach step by step, be honest about uncertainty, and format code clearly. The student's language preference is: ${language}.`;
    try {
      const searchWeb = req.body?.searchWeb === true;
      const openAI = openAIConfig();
      if (openAI) {
        const input = messages.map((message: any) => ({ role: message.role, content: message.content }));
        const payload = await openAIJson("/responses", {
          model: openAI.model,
          instructions: `${system} Do not claim to have searched the web unless the web search tool was enabled and used.`,
          input,
          ...(searchWeb ? { tools: [{ type: "web_search" }], tool_choice: "required" } : {}),
        });
        let content = responseText(payload);
        if (!content) return fail(res, 502, "OpenAI returned no usable answer. Please retry.");
        const sources = searchWeb ? responseSources(payload) : [];
        if (sources.length) content += "\n\nSources:\n" + sources.map((source, index) => `${index + 1}. ${source.title ? `${source.title}: ` : ""}${source.url}`).join("\n");
        return res.json({ content, model: payload?.model || openAI.model, sources });
      }
      const gemini = geminiConfig();
      if (gemini) {
        const contents = normalizeGeminiContents(messages);
        if (!contents.length) return fail(res, 400, "Please send a message before requesting an answer.");
        const payload = await geminiGenerate({
          systemInstruction: { parts: [{ text: system }] },
          contents,
          generationConfig: { temperature: 0.65, maxOutputTokens: 4096 },
          ...(searchWeb ? { tools: [{ google_search: {} }] } : {}),
        });
        const content = geminiText(payload);
        if (!content) return fail(res, 502, "Gemini returned no usable answer. Please retry.");
        const sources = searchWeb ? geminiSources(payload) : [];
        if (sources.length) content += "\n\nSources:\n" + sources.map((source, index) => `${index + 1}. ${source.title ? `${source.title}: ` : ""}${source.url}`).join("\n");
        return res.json({ content, model: gemini.model, sources });
      }
      const payload = await platformJson("/v1/chat/completions", { messages: [{ role: "system", content: system }, ...messages], stream: false });
      const content = payload?.choices?.[0]?.message?.content;
      if (!content || typeof content !== "string") return fail(res, 502, "The AI service returned no usable answer.");
      return res.json({ content, model: payload?.model, sources: [] });
    } catch (error: any) {
      return fail(res, error?.status && error.status >= 400 && error.status < 500 ? error.status : 502, error?.message || "The AI service is unavailable right now.");
    }
  });

  app.post("/api/neuro/image", async (req, res) => {
    if (!clientAllowed(req)) return fail(res, 429, "Too many requests. Please wait a moment and try again.");
    const prompt = typeof req.body?.prompt === "string" ? req.body.prompt.trim().slice(0, 4000) : "";
    if (!prompt) return fail(res, 400, "Please describe the image you want to create.");
    const negative = typeof req.body?.negativePrompt === "string" ? req.body.negativePrompt.trim().slice(0, 1000) : "";
    const style = typeof req.body?.style === "string" ? req.body.style.slice(0, 80) : "Futuristic";
    const aspectRatio = typeof req.body?.aspectRatio === "string" ? req.body.aspectRatio.slice(0, 20) : "1:1";
    try {
      const imagePrompt = `${prompt}. Visual style: ${style}. Composition/aspect preference: ${aspectRatio}.${negative ? ` Avoid these elements: ${negative}.` : ""}`;
      const openAI = openAIConfig();
      if (openAI) {
        const size = aspectRatio === "16:9" || aspectRatio === "4:3" ? "1536x1024" : aspectRatio === "9:16" ? "1024x1536" : "1024x1024";
        const generated = await openAIJson("/images/generations", {
          model: openAI.imageModel,
          prompt: imagePrompt,
          size,
          quality: process.env.OPENAI_IMAGE_QUALITY || "medium",
          n: 1,
          output_format: "png",
        });
        const image = generated?.data?.[0];
        if (!image?.b64_json && !image?.url) return fail(res, 502, "OpenAI returned no usable image. Please retry.");
        return res.json({ url: image.url, b64Json: image.b64_json, mimeType: "image/png", model: openAI.imageModel });
      }
      const hfImage = await generateHuggingFaceImage(imagePrompt, aspectRatio);
      if (hfImage) return res.json(hfImage);
      const models = await platformJson("/images.v1.ImageService/ListModels", {});
      const selectedModel = models?.models?.[0]?.model || models?.models?.[0]?.id;
      const generated = await platformJson("/images.v1.ImageService/GenerateImage", { prompt: imagePrompt, ...(selectedModel ? { model: selectedModel } : {}) });
      const image = generated?.image;
      if (!image?.url && !image?.b64Json) return fail(res, 502, "The image service returned no usable image.");
      return res.json({ url: image.url, b64Json: image.b64Json, mimeType: image.mimeType });
    } catch (error: any) {
      return fail(res, error?.status && error.status >= 400 && error.status < 500 ? error.status : 502, error?.message || "Image generation is unavailable right now.");
    }
  });
}
