import "dotenv/config";
import express from "express";
import { createServer } from "http";
import path from "node:path";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerStorageProxy } from "./storageProxy";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { createCorsMiddleware } from "./cors";
import { clearLegacySessionCookie } from "./cookies";
import { registerNeuroRoutes } from "./neuro";

async function startServer() {
  const app = express();
  // The app is deployed behind a managed reverse proxy (for example Render).
  // Trust one proxy hop so req.ip-based rate limits distinguish real clients.
  app.set("trust proxy", 1);
  const server = createServer(app);

  app.use(createCorsMiddleware());
  app.use(clearLegacySessionCookie());

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerStorageProxy(app);
  registerOAuthRoutes(app);
  registerNeuroRoutes(app);

  app.get("/api/health", (_req, res) => {
    res.json({ ok: true, timestamp: Date.now() });
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    }),
  );

  // Serve the exported Expo web app and keep API routes on the same origin.
  const webBuildPath = path.resolve(process.cwd(), "web-build");
  app.use(express.static(webBuildPath, { index: false, maxAge: process.env.NODE_ENV === "production" ? "1h" : 0 }));
  app.get("*", (req, res, next) => {
    if (req.path.startsWith("/api/") || req.path.startsWith("/manus-storage/")) return next();
    res.sendFile(path.join(webBuildPath, "index.html"), (error) => {
      if (error) next(error);
    });
  });

  const port = parseInt(process.env.PORT || "3000");
  server.listen(port, () => {
    console.log("[api] server listening");
  });
}

startServer().catch((error) => {
  console.error("[api] server failed to start", error);
  process.exitCode = 1;
});
